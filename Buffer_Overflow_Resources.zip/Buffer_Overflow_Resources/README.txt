Read the envirnment_setup.txt file to setup the environment.

The necessary gdb commands are provided in the gdb_cheatsheet.txt file

The other commands are provided in the important_commands.txt file

To generate machine code from assembly, you can use the following site:
https://defuse.ca/online-x86-assembler.htm#disassembly
